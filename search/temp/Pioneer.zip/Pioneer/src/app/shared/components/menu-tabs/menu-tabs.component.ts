import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pion-menu-tabs',
  templateUrl: './menu-tabs.component.html',
  styleUrls: ['./menu-tabs.component.scss']
})
export class MenuTabsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
