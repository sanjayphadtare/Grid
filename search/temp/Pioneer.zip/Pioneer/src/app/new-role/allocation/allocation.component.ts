import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pion-allocation',
  templateUrl: './allocation.component.html',
  styleUrls: ['./allocation.component.scss']
})
export class AllocationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
