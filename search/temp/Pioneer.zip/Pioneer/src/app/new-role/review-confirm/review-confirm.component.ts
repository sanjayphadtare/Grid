import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pion-review-confirm',
  templateUrl: './review-confirm.component.html',
  styleUrls: ['./review-confirm.component.scss']
})
export class ReviewConfirmComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
