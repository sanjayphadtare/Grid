import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pion-change-request',
  templateUrl: './change-request.component.html',
  styleUrls: ['./change-request.component.scss']
})
export class ChangeRequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
