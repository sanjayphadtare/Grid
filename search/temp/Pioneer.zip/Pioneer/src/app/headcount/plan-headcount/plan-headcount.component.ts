import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pion-plan-headcount',
  templateUrl: './plan-headcount.component.html',
  styleUrls: ['./plan-headcount.component.scss']
})
export class PlanHeadcountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
