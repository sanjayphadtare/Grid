import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pion-direct-cost',
  templateUrl: './direct-cost.component.html',
  styleUrls: ['./direct-cost.component.scss']
})
export class DirectCostComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
