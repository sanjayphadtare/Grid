import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pion-plan-allocation',
  templateUrl: './plan-allocation.component.html',
  styleUrls: ['./plan-allocation.component.scss']
})
export class PlanAllocationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
